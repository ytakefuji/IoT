https://create.arduino.cc/projecthub/murthysiddhant/plant-monitor-sensor-to-front-end-c1f715
Codes are modified by takefuji.
Single sensor is used.

com3 data is captured every second.
index.html is updated every second.
access to http://127.0.0.1:5000/ to show the captured data on web.
