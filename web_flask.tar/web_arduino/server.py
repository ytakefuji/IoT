# modified by takefuji

from flask import Flask, jsonify,render_template,request
import webbrowser
import time
import random
import threading, queue
import serial 
import sys
from datetime import datetime

ser = serial.Serial("COM3",115200)
app = Flask(__name__)
q = queue.Queue()

temperature = []
humidity = []
soil_moisture = []
time_ax = []

def data_collection():
    
    while(1):
        #set variables
        i = 0
        #read is blocking so waits till next packet of data is sent
        temperature_r = ser.readline().decode()
        time_of_reading = datetime.now()
        #put data in queue
        q.put(temperature_r)
        q.put(time_of_reading.strftime("%M:%S"))


@app.route("/update", methods = ['GET'])
def update_chart():
    
    while not q.empty():
        temperature.append(q.get())
        time_ax.append(q.get())
    
    return jsonify(results = [temperature,time_ax])


@app.route("/")
def index():
    
    return render_template('index.html')


if __name__ == '__main__':
    x = threading.Thread(target=data_collection)
    x.start()
    app.run(host = '127.0.0.1', port = 5000)
