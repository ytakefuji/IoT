var x = 0;
var temperature = 0;

console.log("welcome");
var ctx = $("#temperature_chart");
console.log("test");
var temperature_chart = new Chart(ctx, {

    type: 'line',
    data: {
        labels: [],
        datasets : [
            {
                label: 'temperature',
                data: [temperature],
                borderColor: [
                    '#060666',
                ],
                borderWidth: 3,
                fill: false,
                yAxisID: "temperature"
            }
            

        ]
    },
    
    options: {
        responsive: false,
        scales:{
            
            xAxes: [ {
                //type: 'time',
                display: true,
                scaleLabel : {
                    display: true,
                    labelString: 'Time (s)'
                    
                    },
                ticks: {
                   autoSkip: true,
                   maxTicksLimit: 12
                }
                }],
            yAxes: [ {
                id: "temperature",
                display: true,
                position: 'left',
                ticks: {
                    suggestedMin: 15,
                    suggestedMax: 30
                    },
                scaleLabel : {
                    display: true,

                    labelString: 'Temperature (C)'
                    
                    }
                }
                ]
            }

    }

});


var updated_data  = $.get('/update');

updated_data.done(function(results){
    temperature = results.results[0];
    x = results.results[1];
    
    console.log(temperature);
    
    temperature_chart.data.datasets[0].data = temperature;

    temperature_chart.data.labels = x;

    temperature_chart.update();

    });
